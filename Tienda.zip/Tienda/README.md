<h2>Instalamos dependencias:</h2>

<p>npm install sass - Librería SASS</p>
<p>npm install json-server - Simular un servidor de JSON</p>

<h2>Iniciamos SASS:</h2>

<p>sass ./src/sass/:./src/css/ --watch</p>

<h2>Iniciamos JSON-SERVER:</h2>

<p>npx json-server db.json</p>